package com.fpoly.lab;

import com.fpoly.lab.dao.UserManager;
import com.fpoly.lab.entity.User;

import java.util.List;

public class UserTest {

    private static void printHeader(String title) {
        System.out.println("\n==============================");
        System.out.println(title);
        System.out.println("==============================");
    }

    public static void main(String[] args) {
        UserManager um = new UserManager();

        try {
            // BÀI 2: findAll
            printHeader("BÀI 2 - findAll()");
            List<User> all = um.getAll();
            System.out.println("Total users = " + all.size());
            all.forEach(u -> System.out.println(u.getId() + " | " + u.getFullname() + " | admin=" + u.getAdmin()));

            // BÀI 2: findById
            printHeader("BÀI 2 - findById('U01')");
            User u01 = um.getById("U01");
            if (u01 == null) {
                System.out.println("U01 NOT FOUND");
            } else {
                System.out.println("FOUND: " + u01.getId() + " | " + u01.getFullname() + " | admin=" + u01.getAdmin());
            }

            // BÀI 2: create (an toàn, chạy nhiều lần không lỗi)
            printHeader("BÀI 2 - createIfNotExists('U99')");
            boolean created = um.createIfNotExists(
                    new User("U99", "123", "Test User", "test@fpt.edu.vn", false)
            );
            System.out.println(created ? "CREATE OK" : "SKIP (U99 existed)");

            // BÀI 2: update
            printHeader("BÀI 2 - update('U99')");
            um.update(new User("U99", "123", "Test User Updated", "updated@fpt.edu.vn", false));
            System.out.println("UPDATE OK");

            // BÀI 3
            printHeader("BÀI 3 - Email endsWith @fpt.edu.vn AND admin=false");
            List<User> b3 = um.findNonAdminFptEmails();
            System.out.println("Result size = " + b3.size());
            b3.forEach(u -> System.out.println(u.getId() + " | " + u.getFullname() + " | " + u.getEmail() + " | admin=" + u.getAdmin()));

            // BÀI 4
            printHeader("BÀI 4 - Page 3 (index=2) size=5");
            int pageIndex = 2;
            int pageSize = 5;
            List<User> page = um.findPage(pageIndex, pageSize);

            System.out.println("Returned rows = " + page.size());
            page.forEach(u -> System.out.println(u.getId() + " | " + u.getFullname() + " | " + u.getEmail()));

            if (page.size() == 5) {
                System.out.println("BÀI 4: OK (đủ 5 dòng)");
            } else {
                System.out.println("BÀI 4: CHƯA OK (thiếu dữ liệu, cần > 10 users để có trang 3)");
            }

        } finally {
            um.close();
            System.out.println("\nDONE ✅");
        }
    }
}
