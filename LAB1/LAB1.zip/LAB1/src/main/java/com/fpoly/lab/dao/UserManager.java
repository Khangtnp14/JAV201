package com.fpoly.lab.dao;

import com.fpoly.lab.entity.User;
import jakarta.persistence.*;

import java.util.List;

public class UserManager {

    private final EntityManagerFactory factory = Persistence.createEntityManagerFactory("PolyOE");
    private final EntityManager em = factory.createEntityManager();


    public List<User> getAll() {
        String jpql = "SELECT o FROM User o ORDER BY o.id";
        return em.createQuery(jpql, User.class).getResultList();
    }

    public User getById(String userId) {
        return em.find(User.class, userId);
    }

    // ===== CRUD =====
    public boolean createIfNotExists(User user) {
        if (em.find(User.class, user.getId()) != null) {
            return false; // đã tồn tại
        }
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(user);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    public void update(User user) {
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.merge(user);
            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    public boolean deleteById(String userId) {
        EntityTransaction tx = em.getTransaction();
        try {
            User user = em.find(User.class, userId);
            if (user == null) return false;

            tx.begin();
            em.remove(user);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    // ===== BÀI 3 =====
    public List<User> findNonAdminFptEmails() {
        String jpql = "SELECT o FROM User o WHERE o.email LIKE :search AND o.admin = :role ORDER BY o.id";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setParameter("search", "%@fpt.edu.vn");
        query.setParameter("role", false);
        return query.getResultList();
    }

    // ===== BÀI 4 =====
    public List<User> findPage(int pageNumberZeroBased, int pageSize) {
        String jpql = "SELECT o FROM User o ORDER BY o.id";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        query.setFirstResult(pageNumberZeroBased * pageSize);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    public void close() {
        em.close();
        factory.close();
    }
}
