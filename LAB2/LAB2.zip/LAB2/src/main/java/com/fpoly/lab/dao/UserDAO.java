package com.fpoly.lab.dao;

import com.fpoly.lab.entity.User;

import java.util.List;

public interface UserDAO {
    List<User> findAll();

    User findById(String id);

    void create(User item);

    void update(User item);

    void deleteById(String id);
}
